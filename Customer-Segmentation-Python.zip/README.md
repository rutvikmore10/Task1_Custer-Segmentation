
# Customer Segmentation Using Python

This project segments customers based on income and spending behavior.

## Files
- customer_segmentation.py
- dataset/customers.csv

## How to Run
pip install -r requirements.txt
python customer_segmentation.py
